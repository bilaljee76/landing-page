<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'acf' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '~49#40-+0bL2UM%!za9Bu}<XS$m.VAScm*n7D/Z:n43miYPiqz@XgR( T}BERaUJ' );
define( 'SECURE_AUTH_KEY',  'kHyWN-,}Fq_Q`P/INvb9$r77=er8IX`oo>d-q{%o~zB>k4dNT@))RFs#FtI?1kK&' );
define( 'LOGGED_IN_KEY',    'fCTR}@gu,U6+9aSmqw$95%k@)0G*zv:x0:HY!!NU_QMsc:j;9DD3$SVLL8DLG`A1' );
define( 'NONCE_KEY',        'j^i((-0pvN;XmXUEIQ?TLLMV?3>)VcSot_/>q_x`slP<kz8P~:d.vSAU^GD.9NkP' );
define( 'AUTH_SALT',        'e BxoWF~BSXsySVb{Dg$w08PrZqCEXs)+eL~cP1;}RQPpJP):-N?`Rc#:bTq/n}=' );
define( 'SECURE_AUTH_SALT', 'H]?!w6:j-5u3WsFx7{XFerAy@5r1uDOXH)r_eAZdGX1vd7DM#8i;#PnX;*dcx!k$' );
define( 'LOGGED_IN_SALT',   'P_P$*fgWw(I$03*Jrumv?MXUxTsHAxC049Hq&Tkd$$@*t95>j5PzMIh2Y!+eFCoo' );
define( 'NONCE_SALT',       ']zchu7O)cGDb0/I8HZC,XZ5@s}t:amF{Sz_zGCO;9cR%l84=*[Ms3)KNeaGL@a[h' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
